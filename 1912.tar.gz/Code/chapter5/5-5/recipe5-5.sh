#!/bin/bash

grep -E "<[^\/>]+[[:space:]]summary=[\'\"][^\'\"]*[\'\"]" sample.html
