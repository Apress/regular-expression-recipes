#!/bin/bash

sed 's/^\/\///' sample.c 
