#!/bin/bash

sed 's/\<MyMethod[[:space:]]*(/MyNewMethod (/g' sample.txt
