WORD
/* WORD */
/** WORD **/
/* Not this one */ WORD /* No */
// WORD
WORD // Not this one
