#!/bin/bash 

grep '^[[:space:]]*\(public\|private\)[[:space:]]\+int[[:space:]]\+MyMethod[[:space:]]*(' sample.txt
