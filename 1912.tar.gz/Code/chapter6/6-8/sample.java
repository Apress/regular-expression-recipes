public class MyClass {

	public int myvar = moo;
	/* variable here */ public int myvar = moo;
	/* another variable here */ public int myvar = moo; /* a comment here */
	/* public int myvar = moo; */
	// public int myvar = oink;

	public static void main ( String[] args )
	{
		int myvar = moo;
	}
}
