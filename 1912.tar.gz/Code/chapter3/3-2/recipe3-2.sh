#!/bin/bash

grep '^[^	]\+\(	[^	]\+\)\{4\}$' sample.tab 
