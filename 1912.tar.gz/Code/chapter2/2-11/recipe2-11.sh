#!/bin/bash
find . -regex '^\.\/[-A-z0-9_.]+\.(te?xt|TXT)$'
