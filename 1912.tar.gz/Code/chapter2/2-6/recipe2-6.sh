#!/bin/sh

sed 's/^\/\(.*\)\/[^\/]\+$/\/\1/' sample.txt
