#!/bin/sh

sed 's/^.\+\.\([A-z0-9_]\{2,4\}\)$/\1/' sample.txt
