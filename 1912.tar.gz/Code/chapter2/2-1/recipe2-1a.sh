#!/bin/bash

ls -l | grep '\log[-]200406\(0[1-9]\|[12][0-9]\)\.log' 
