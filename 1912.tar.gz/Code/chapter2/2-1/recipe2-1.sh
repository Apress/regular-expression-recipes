#!/bin/bash
find . -regex '\.\/log[-]200406\(0[1-9]\|2[0-9]\)\.log'
