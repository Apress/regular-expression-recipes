#!/bin/bash

grep -E '^([0-9]{4}[- ]?){3}[0-9]{4}$' sample.txt 
