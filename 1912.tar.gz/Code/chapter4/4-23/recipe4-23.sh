#!/bin/bash

grep -i '^\(t\(rue\)\?\|y\(es\)\?\)$' sample.txt 
