#!/bin/bash

sed 's/^\([^@]\+\)\(@.*\)$/\1/g' sample.txt 
