#!/bin/bash

grep -E '^.{0,15}$' sample.txt
