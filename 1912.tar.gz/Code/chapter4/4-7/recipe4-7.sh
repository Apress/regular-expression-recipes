#!/bin/bash

grep '^[A-z]\+$' sample.txt 
