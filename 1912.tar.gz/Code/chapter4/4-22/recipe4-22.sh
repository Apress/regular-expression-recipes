#!/bin/bash

grep -E -i '^(P\.?O\.?[[:space:]])?(BOX)' sample.txt 
