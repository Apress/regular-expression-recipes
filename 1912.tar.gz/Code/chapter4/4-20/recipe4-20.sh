#!/bin/bash

sed 's/^\+\([0-9]{1,3}\)\([- ]+.*\)$/\1/g' sample.txt 
