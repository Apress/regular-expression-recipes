#!/bin/bash

 grep -E '^[0-9]{5}(-[0-9]{4})?$' sample.txt
