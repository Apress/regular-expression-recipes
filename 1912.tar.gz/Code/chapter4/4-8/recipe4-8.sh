#!/bin/bash

grep '^\$[0-9]\+\.[0-9][0-9]$' sample.txt
