#!/bin/sh

grep '\"[^\"]*\<neat saying\>[^\"]*\"' sample.txt
