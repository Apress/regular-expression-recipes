#!/bin/sh

grep '[[:space:]]\+\(\(oink\)\|\(moo\)\)[[:space:]]\+' sample.txt
