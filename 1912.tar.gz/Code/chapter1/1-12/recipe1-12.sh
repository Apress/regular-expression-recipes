#!/bin/sh

grep "^Word\>" sample.txt
