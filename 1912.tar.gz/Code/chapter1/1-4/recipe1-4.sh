#!/bin/sh

grep 'Joh\?n\(athan\)\? Doe' sample.txt
