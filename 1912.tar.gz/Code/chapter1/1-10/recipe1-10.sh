#!/bin/sh

grep -E '\<([[:alpha:]]+)[[:space:]]+\1\>' sample.txt
