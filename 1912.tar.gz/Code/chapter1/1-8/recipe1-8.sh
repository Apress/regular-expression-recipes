#!/bin/sh

sed 's/\t/|/g' sample.txt
