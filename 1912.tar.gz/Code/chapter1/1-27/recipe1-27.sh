#!/bin/sh

sed 's/#.*$//g' sample.txt
