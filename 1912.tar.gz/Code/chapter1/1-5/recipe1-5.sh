#!/bin/sh

grep '\<[cbm]at\>' sample.txt
