#!/bin/sh

grep '\<word$' sample.txt 
