#!/bin/sh

grep '^[[:space:]]*$' sample.txt 
