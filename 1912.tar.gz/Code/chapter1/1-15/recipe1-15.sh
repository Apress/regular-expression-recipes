#!/bin/sh

grep '\<[Ss]\+[[:space:]]*[Pp]\+[[:space:]]*[Aa4]\+[[:space:]]*[Mm]*\>' sample.txt 
