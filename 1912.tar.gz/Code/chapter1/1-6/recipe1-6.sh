#!/bin/sh

sed 's/\<frick\>/frack/g' sample.txt
